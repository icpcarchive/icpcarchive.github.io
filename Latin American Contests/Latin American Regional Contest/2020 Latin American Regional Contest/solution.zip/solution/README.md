Congratulations to the contestants that made it to world finals!!

I think this was one of the most competed regionals I've ever seen!

I feel like the quality of the problems has been going up in the past 10 years, so congratulations to all of the problem setters as well!

Scoreboard: https://scorelatam.naquadah.com.br/latam-2020/?fbclid=IwAR2L3sSAX_iD4oB01HVewrlnqZpbm4hVw6aEg-u4FOkZ0CutkFbtgLKPuMQ#

Here I give a subjective difficulty to the problems:<br /> 
Easy: DLN<br /> 
Medium-Easy: CEK<br /> 
Medium-Hard: BFHJ<br /> 
Hard: AGI<br /> 
Very Hard: M<br /> 

For Mexico solving all of Easy, Medium-Easy and 2 of the Medium-Hard would guarantee pass to world finals.

For other regions solving some/all of the Medium-Hard would also guarantee pass.

Every problem was solved during the contest by at least 1 team, congratulations to the teams that solved the harder problems!

DP was the most common topic it could be used in 6 of the problems, also for all DP problems (except L) they required a non-trivial transformation or optimization.

Notes on M: It was very hard, I think it was comparable in difficulty to https://open.kattis.com/problems/firstofhername. Would recommend finalists to solve this problem.

Link to editorial: https://github.com/Diego1149/ICPC-Latam-2020

For the difficulty in the editorial I assigned it based on the relative difficulty of the contest itself, meaning 1 to the easiest, 10 to the hardest.

Let me know if you have any questions or think I should update any of the editorials!
